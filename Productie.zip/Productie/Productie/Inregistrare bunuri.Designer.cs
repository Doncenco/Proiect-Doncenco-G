﻿
namespace Productie
{
    partial class Inregistrare_bunuri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label cbMaterial;
            System.Windows.Forms.Label label3;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inregistrare_bunuri));
            this.cb_mater = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.nCant = new System.Windows.Forms.NumericUpDown();
            cbMaterial = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nCant)).BeginInit();
            this.SuspendLayout();
            // 
            // cbMaterial
            // 
            cbMaterial.AutoSize = true;
            cbMaterial.Location = new System.Drawing.Point(12, 34);
            cbMaterial.Name = "cbMaterial";
            cbMaterial.Size = new System.Drawing.Size(44, 13);
            cbMaterial.TabIndex = 4;
            cbMaterial.Text = "Material";
            // 
            // cb_mater
            // 
            this.cb_mater.FormattingEnabled = true;
            this.cb_mater.Location = new System.Drawing.Point(115, 31);
            this.cb_mater.Name = "cb_mater";
            this.cb_mater.Size = new System.Drawing.Size(200, 21);
            this.cb_mater.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(115, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 35);
            this.button1.TabIndex = 20;
            this.button1.Text = "Inregistreaza";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "label1";
            // 
            // nCant
            // 
            this.nCant.Location = new System.Drawing.Point(115, 84);
            this.nCant.Name = "nCant";
            this.nCant.Size = new System.Drawing.Size(200, 20);
            this.nCant.TabIndex = 15;
            this.nCant.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(12, 84);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(52, 13);
            label3.TabIndex = 14;
            label3.Text = "Cantitate:";
            // 
            // Inregistrare_bunuri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(327, 186);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(cbMaterial);
            this.Controls.Add(this.cb_mater);
            this.Controls.Add(label3);
            this.Controls.Add(this.nCant);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Inregistrare_bunuri";
            this.Text = "Inregistrare_Textile";
            ((System.ComponentModel.ISupportInitialize)(this.nCant)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cb_mater;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown nCant;
    }
}