﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Productie
{
    public partial class Form1 : Form
    {
        SQL sqlComenzi = new SQL();       
        string[] criteria = { "is not null", "is not null", "is not null", "is not null" };

        public Form1()
        {
            InitializeComponent();

            dataGridView1.DataSource = sqlComenzi.getData("select * from Documente ");
        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            new Transfera().Show();
        }

        private void cauta            (object sender, EventArgs e)
        {
           
            if (toolStripTextBox1.Text != "Toate" && toolStripTextBox1.Text != "")
                criteria[1] = " = '" + toolStripTextBox1.Text + "'";
            else
                criteria[1] = " is not null ";

            if (ts_tb_NI.Text != "")
                criteria[2] = " like '%" + ts_tb_NI.Text + "%'";
            else
                criteria[2] = " is not null ";

            if (ts_tb_Den.Text != "")
                criteria[3] = " like '%" + ts_tb_Den.Text + "%'";
            else
                criteria[3] = " is not null ";

            dataGridView1.DataSource = sqlComenzi.getData("select * from Documente " +
               " where [Depozit] " + criteria[1] +
               " and [Magazine] " + criteria[2] +
               " and [Denumire] " + criteria[3]);
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            toolStripTextBox1.Text = "";
            ts_tb_NI.Text = "";
            ts_tb_Den.Text = "";
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            System.Windows.Forms.Application.ExitThread();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            new Adauga_Haine_Depozit().Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            new Inregistrare_bunuri().Show();
        }

        private void toolStripButton5_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = sqlComenzi.getData("select * from Documente ");
        }
    
    }
}
