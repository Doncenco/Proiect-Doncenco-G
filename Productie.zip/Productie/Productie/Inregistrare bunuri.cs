﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Productie
{
    public partial class Inregistrare_bunuri : Form
    {
        SQL sqlComenzi = new SQL();
        public Inregistrare_bunuri()
        {
            InitializeComponent();
            label1.Text = "";
            loadcbList();
        }
        void loadcbList()
        {
            List<string> a = sqlComenzi.SQL_loadData("select distinct([Material]) from [Materiale Textile] ");
            cb_mater.Items.Clear();


            foreach (var item in a)
                cb_mater.Items.Add(item);

            cb_mater.Items.Add("");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sqlComenzi.SQLinsert("insert [materiale textile] ([Material],Cantitate)" +
                "values('"+cb_mater.Text+"' ,'"+nCant.Text+"')");  
            
            label1.Text = "Ati adaugat inregistrarea cu succes; ";
            cb_mater.Text = "";
            nCant.Text = "";
            loadcbList();
        }

    }
}
