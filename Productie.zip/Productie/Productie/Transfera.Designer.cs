﻿
namespace Productie
{
    partial class Transfera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label data_intrarii_in_stocLabel;
            System.Windows.Forms.Label cantitateLabel;
            System.Windows.Forms.Label denumireLabel;
            System.Windows.Forms.Label depozitLabel;
            System.Windows.Forms.Label magazineLabel;
            System.Windows.Forms.Label pretLabel;
            this.magazineTextBox = new System.Windows.Forms.TextBox();
            this.pretTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.cb_DenumireH = new System.Windows.Forms.ComboBox();
            this.cb_depozit = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            data_intrarii_in_stocLabel = new System.Windows.Forms.Label();
            cantitateLabel = new System.Windows.Forms.Label();
            denumireLabel = new System.Windows.Forms.Label();
            depozitLabel = new System.Windows.Forms.Label();
            magazineLabel = new System.Windows.Forms.Label();
            pretLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // data_intrarii_in_stocLabel
            // 
            data_intrarii_in_stocLabel.AutoSize = true;
            data_intrarii_in_stocLabel.Location = new System.Drawing.Point(12, 9);
            data_intrarii_in_stocLabel.Name = "data_intrarii_in_stocLabel";
            data_intrarii_in_stocLabel.Size = new System.Drawing.Size(97, 13);
            data_intrarii_in_stocLabel.TabIndex = 1;
            data_intrarii_in_stocLabel.Text = "Data intrarii in stoc:";
            // 
            // cantitateLabel
            // 
            cantitateLabel.AutoSize = true;
            cantitateLabel.Location = new System.Drawing.Point(12, 61);
            cantitateLabel.Name = "cantitateLabel";
            cantitateLabel.Size = new System.Drawing.Size(52, 13);
            cantitateLabel.TabIndex = 5;
            cantitateLabel.Text = "Cantitate:";
            // 
            // denumireLabel
            // 
            denumireLabel.AutoSize = true;
            denumireLabel.Location = new System.Drawing.Point(12, 35);
            denumireLabel.Name = "denumireLabel";
            denumireLabel.Size = new System.Drawing.Size(86, 13);
            denumireLabel.TabIndex = 7;
            denumireLabel.Text = "Denumire Haine:";
            // 
            // depozitLabel
            // 
            depozitLabel.AutoSize = true;
            depozitLabel.Location = new System.Drawing.Point(12, 128);
            depozitLabel.Name = "depozitLabel";
            depozitLabel.Size = new System.Drawing.Size(72, 13);
            depozitLabel.TabIndex = 9;
            depozitLabel.Text = "de la Depozit:";
            // 
            // magazineLabel
            // 
            magazineLabel.AutoSize = true;
            magazineLabel.Location = new System.Drawing.Point(12, 154);
            magazineLabel.Name = "magazineLabel";
            magazineLabel.Size = new System.Drawing.Size(61, 13);
            magazineLabel.TabIndex = 11;
            magazineLabel.Text = "la Magazin:";
            // 
            // pretLabel
            // 
            pretLabel.AutoSize = true;
            pretLabel.Location = new System.Drawing.Point(12, 87);
            pretLabel.Name = "pretLabel";
            pretLabel.Size = new System.Drawing.Size(29, 13);
            pretLabel.TabIndex = 13;
            pretLabel.Text = "Pret:";
            // 
            // magazineTextBox
            // 
            this.magazineTextBox.Location = new System.Drawing.Point(115, 151);
            this.magazineTextBox.Name = "magazineTextBox";
            this.magazineTextBox.Size = new System.Drawing.Size(100, 20);
            this.magazineTextBox.TabIndex = 12;
            // 
            // pretTextBox
            // 
            this.pretTextBox.Location = new System.Drawing.Point(115, 84);
            this.pretTextBox.Name = "pretTextBox";
            this.pretTextBox.Size = new System.Drawing.Size(100, 20);
            this.pretTextBox.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 234);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "label4";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(36, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(179, 35);
            this.button1.TabIndex = 24;
            this.button1.Text = "Adauga";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // cb_DenumireH
            // 
            this.cb_DenumireH.FormattingEnabled = true;
            this.cb_DenumireH.Location = new System.Drawing.Point(115, 33);
            this.cb_DenumireH.Name = "cb_DenumireH";
            this.cb_DenumireH.Size = new System.Drawing.Size(100, 21);
            this.cb_DenumireH.TabIndex = 26;
            // 
            // cb_depozit
            // 
            this.cb_depozit.FormattingEnabled = true;
            this.cb_depozit.Location = new System.Drawing.Point(115, 124);
            this.cb_depozit.Name = "cb_depozit";
            this.cb_depozit.Size = new System.Drawing.Size(100, 21);
            this.cb_depozit.TabIndex = 26;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(115, 7);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker1.TabIndex = 27;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(115, 58);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(100, 20);
            this.numericUpDown1.TabIndex = 28;
            this.numericUpDown1.UpDownAlign = System.Windows.Forms.LeftRightAlignment.Left;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // Transfera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(243, 256);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.cb_depozit);
            this.Controls.Add(this.cb_DenumireH);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button1);
            this.Controls.Add(data_intrarii_in_stocLabel);
            this.Controls.Add(cantitateLabel);
            this.Controls.Add(denumireLabel);
            this.Controls.Add(depozitLabel);
            this.Controls.Add(magazineLabel);
            this.Controls.Add(this.magazineTextBox);
            this.Controls.Add(pretLabel);
            this.Controls.Add(this.pretTextBox);
            this.Name = "Transfera";
            this.Text = "Transfera";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox magazineTextBox;
        private System.Windows.Forms.TextBox pretTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox cb_DenumireH;
        private System.Windows.Forms.ComboBox cb_depozit;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
    }
}