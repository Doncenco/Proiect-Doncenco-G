﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Productie
{
    public partial class Transfera : Form
    {
        SQL sqlComenzi = new SQL();
        public Transfera()
        {
            InitializeComponent();
            loadcbList();
            label4.Text = "";
        }

        void loadcbList()
        {
            List<string> a = sqlComenzi.SQL_loadData("select distinct([denumire_haine]) from [depozite] ");
            cb_DenumireH.Items.Clear();
            foreach (var item in a)
                cb_DenumireH.Items.Add(item);

            List<string> a1 = sqlComenzi.SQL_loadData("select distinct([denumire_nr]) from [depozite] ");
            cb_depozit.Items.Clear();
            foreach (var item in a1)
                cb_depozit.Items.Add(item);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            sqlComenzi.SQLinsert("insert [documente] ([Data],Cantitate,Denumire,[Depozit],[Magazine],[Pret])" +
             "values('" + dateTimePicker1.Text + "' ,'" +
              numericUpDown1.Text + "' ,'" +
               cb_DenumireH.Text + "' ,'" +
                cb_depozit.Text + "' ,'" +
                 magazineTextBox.Text + "' ,'" +
                  pretTextBox.Text + "')");

            label4.Text = "Ati transferat la magazinul " + magazineTextBox.Text + " cu succes; ";
            numericUpDown1.Text = "";
            cb_DenumireH.Text = "";
            cb_depozit.Text = "";
            magazineTextBox.Text = "";
            pretTextBox.Text = "";
        }
    }
}
