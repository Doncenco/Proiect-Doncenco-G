﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Productie
{
    public partial class Adauga_Haine_Depozit : Form
    {
        SQL sqlComenzi = new SQL();
        public Adauga_Haine_Depozit()
        {
            InitializeComponent();
            label4.Text = "";

            List<string> a1 = sqlComenzi.SQL_loadData("select distinct([denumire_nr]) from [depozite] ");
            comboBox1.Items.Clear();
            foreach (var item in a1)
                comboBox1.Items.Add(item);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sqlComenzi.SQLinsert("insert [depozite] ([denumire_nr],[denumire_haine],Cantitate)" +
              "values('" + comboBox1.Text + "' ,'" + textBox2.Text + "','"+nCant.Text+"')");

            label4.Text = "Ati adaugat inregistrarea cu succes; ";
            comboBox1.Text = "";
            textBox2.Text = "";
            nCant.Text = "";

        }
    }
}
